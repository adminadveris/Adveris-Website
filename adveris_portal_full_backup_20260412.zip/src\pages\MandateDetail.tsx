import { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { mockApi } from '../lib/mockApi';

const STATUSES_MAP: Record<string, { label: string; color: string }> = {
  pending: { label: 'Pending', color: 'var(--saffron)' },
  approved: { label: 'Approved', color: '#22c55e' },
  rejected: { label: 'Rejected', color: '#ef4444' },
  clarification_required: { label: 'Clarification Required', color: '#a78bfa' },
  in_progress: { label: 'In Progress', color: '#38bdf8' },
};


const SERVICE_NAMES = [
  'Corporate Advisory & Structuring',
  'Venture Capital, Private Equity & Fundraises',
  'Mergers & Acquisitions',
  'Loans & Debt Financing',
  'Commercial Contracts',
  'Employment Law',
  'Regulatory Compliance',
  'Due Diligence',
  'Dispute & Pre-Litigation',
  'Business Valuation',
  'Authorities Representation',
  'Bankruptcy & Insolvency',
];

const fmt = (iso: string) =>
  new Date(iso).toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });

/* ── Field wrapper ── */
const Field = ({
  label, children, span,
}: {
  label: string; children: React.ReactNode; span?: boolean;
}) => (
  <div style={{ gridColumn: span ? '1 / -1' : undefined }}>
    <p style={{
      fontSize: '0.58rem', fontWeight: 700, letterSpacing: '0.22em',
      textTransform: 'uppercase', color: 'rgba(255,255,255,0.3)', marginBottom: 10
    }}>
      {label}
    </p>
    {children}
  </div>
);

/* ── Shared input styles ── */
const inp: React.CSSProperties = {
  width: '100%', padding: '12px 16px',
  background: 'rgba(255,255,255,0.05)', border: '1.5px solid rgba(255,255,255,0.12)',
  borderRadius: 12, color: 'white', fontSize: '0.95rem',
  fontFamily: 'var(--font-sans)', outline: 'none', transition: 'border-color 0.2s ease',
};

const readVal: React.CSSProperties = {
  fontSize: '0.95rem', color: 'white', lineHeight: 1.6,
};

const empty: React.CSSProperties = {
  fontSize: '0.9rem', color: 'rgba(255,255,255,0.25)', fontStyle: 'italic',
};

/* ── StatusBadge ── */
const StatusBadge = ({ status }: { status: string }) => {
  const s = STATUSES_MAP[status] || { label: status, color: 'var(--saffron)' };
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 8,
      fontSize: '0.72rem', fontWeight: 700, letterSpacing: '0.14em', textTransform: 'uppercase',
      color: s.color, background: `${s.color}18`, padding: '7px 16px',
      borderRadius: 'var(--radius-pill)', border: `1px solid ${s.color}35`
    }}>
      <span style={{ width: 6, height: 6, borderRadius: '50%', background: s.color }} />
      {s.label}
    </span>
  );
};

/* ── Section card ── */
const Card = ({ title, children }: { title: string; children: React.ReactNode }) => (
  <div style={{
    background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.07)',
    borderRadius: 20, padding: 32, marginBottom: 24,
  }}>
    <p style={{
      fontSize: '0.6rem', fontWeight: 700, letterSpacing: '0.22em', textTransform: 'uppercase',
      color: 'var(--saffron)', marginBottom: 28, display: 'flex', alignItems: 'center', gap: 10,
    }}>
      <span style={{ display: 'inline-block', width: 20, height: 1.5, background: 'var(--saffron)' }} />
      {title}
    </p>
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '24px 40px' }}>
      {children}
    </div>
  </div>
);

/* ══════════════════════════════════════════════
   MAIN PAGE
   ══════════════════════════════════════════════ */
const MandateDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  const [profile, setProfile] = useState<any>(null);
  const [record, setRecord] = useState<any>(null);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  // Editable state
  const [status, setStatus] = useState('');
  const [service, setService] = useState('');
  const [priority, setPriority] = useState('Medium');
  const [assignedTo, setAssignedTo] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [internalNotes, setInternalNotes] = useState('');
  const [clientComms, setClientComms] = useState('');
  const [account, setAccount] = useState<any>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [showAllHistory, setShowAllHistory] = useState(false);

  const loadRecord = async () => {
    const [p, allRecords, allAccounts, hist] = await Promise.all([
      mockApi.getProfile(),
      mockApi.getRecords(),
      mockApi.getAccounts(),
      mockApi.getHistoryByRecord(id!),
    ]);
    const found = allRecords.find((r: any) => r.id === id);
    setProfile(p);
    setRecord(found || null);
    setHistory(hist);
    if (found) {
      const acc = allAccounts.find((a: any) => a.id === found.account_id);
      setAccount(acc);
      setStatus(found.status || 'pending');
      setService(found.primary_service || '');
      setPriority(found.priority || 'Medium');
      setAssignedTo(found.assigned_to || '');
      setDueDate(found.due_date || '');
      setInternalNotes(found.internal_notes || '');
      setClientComms(found.client_comms || '');
    }
  };

  useEffect(() => { loadRecord(); }, [id]);

  if (!profile || !record) {
    return (
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '60vh' }}>
        <p style={{ fontFamily: 'var(--font-serif)', fontSize: '1.5rem', color: 'rgba(255,255,255,0.2)', fontStyle: 'italic' }}>
          {record === null ? 'Record not found.' : 'Loading…'}
        </p>
      </div>
    );
  }

  const isClient = profile.role === 'client';
  const canEdit = !isClient;

  const priorityColor = priority === 'High' ? '#ef4444' : priority === 'Low' ? '#22c55e' : 'var(--saffron)';

  const handleSave = async () => {
    setSaving(true);
    try {
      await mockApi.updateRecord(record.id, {
        status, primary_service: service, priority,
        assigned_to: assignedTo, due_date: dueDate,
        internal_notes: internalNotes, client_comms: clientComms,
      });
      setSaved(true);
      setEditing(false);
      await loadRecord();
      setTimeout(() => setSaved(false), 3000);
    } finally { setSaving(false); }
  };

  return (
    <div style={{ maxWidth: 960, margin: '0 auto' }}>

      {/* ── Page Header ── */}
      <div style={{ marginBottom: 40 }}>
        {/* Back link */}
        <button
          onClick={() => navigate('/dashboard/records')}
          style={{
            display: 'inline-flex', alignItems: 'center', gap: 8,
            fontSize: '0.65rem', fontWeight: 700, letterSpacing: '0.15em', textTransform: 'uppercase',
            color: 'rgba(255,255,255,0.35)', background: 'none', border: 'none',
            cursor: 'pointer', marginBottom: 28, padding: 0, transition: 'color 0.2s',
          }}
          onMouseOver={e => (e.currentTarget as HTMLElement).style.color = 'var(--saffron)'}
          onMouseOut={e => (e.currentTarget as HTMLElement).style.color = 'rgba(255,255,255,0.35)'}
        >
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
            <line x1="19" y1="12" x2="5" y2="12" /><polyline points="12 19 5 12 12 5" />
          </svg>
          Back to Records
        </button>

        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', flexWrap: 'wrap', gap: 20 }}>
          <div>
            <p style={{ fontSize: '0.6rem', fontWeight: 700, letterSpacing: '0.22em', textTransform: 'uppercase', color: 'var(--saffron)', marginBottom: 8 }}>
              — {account?.account_name || 'Individual Request'}
            </p>
            <h1 style={{ fontFamily: 'var(--font-serif)', fontSize: 'clamp(2rem, 5vw, 3.5rem)', color: 'white', fontWeight: 400, lineHeight: 1.05, marginBottom: 16 }}>
              {record.request_number}
            </h1>
            <div style={{ display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
              <StatusBadge status={status} />
              <span style={{ fontSize: '0.78rem', color: 'rgba(255,255,255,0.3)' }}>
                Submitted {fmt(record.created_at)}
              </span>
            </div>
          </div>

          <div style={{ display: 'flex', gap: 12, alignItems: 'center' }}>
            {saved && (
              <span style={{ fontSize: '0.75rem', color: '#22c55e', fontWeight: 600 }}>
                ✓ Saved
              </span>
            )}
            {canEdit && !editing && (
              <button
                onClick={() => setEditing(true)}
                style={{
                  display: 'inline-flex', alignItems: 'center', gap: 8,
                  padding: '12px 24px', background: 'rgba(255,255,255,0.06)',
                  border: '1px solid rgba(255,255,255,0.12)', borderRadius: 'var(--radius-pill)',
                  color: 'white', fontSize: '0.75rem', fontWeight: 700,
                  letterSpacing: '0.12em', textTransform: 'uppercase', cursor: 'pointer',
                  transition: 'all 0.2s ease',
                }}
                onMouseOver={e => { (e.currentTarget as HTMLElement).style.borderColor = 'var(--saffron)'; (e.currentTarget as HTMLElement).style.color = 'var(--saffron)'; }}
                onMouseOut={e => { (e.currentTarget as HTMLElement).style.borderColor = 'rgba(255,255,255,0.12)'; (e.currentTarget as HTMLElement).style.color = 'white'; }}
              >
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                  <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                </svg>
                Edit Record
              </button>
            )}
            {editing && (
              <>
                <button
                  onClick={() => { setEditing(false); loadRecord(); }}
                  style={{ padding: '12px 24px', background: 'transparent', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 'var(--radius-pill)', color: 'rgba(255,255,255,0.5)', fontSize: '0.75rem', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', cursor: 'pointer' }}
                >
                  Cancel
                </button>
                <button
                  onClick={handleSave}
                  disabled={saving}
                  style={{
                    display: 'inline-flex', alignItems: 'center', gap: 8,
                    padding: '12px 28px', background: saving ? 'rgba(255,153,51,0.5)' : 'var(--saffron)',
                    color: 'var(--navy)', border: 'none', borderRadius: 'var(--radius-pill)',
                    fontSize: '0.75rem', fontWeight: 700, letterSpacing: '0.12em',
                    textTransform: 'uppercase', cursor: saving ? 'not-allowed' : 'pointer',
                    transition: 'all 0.2s ease',
                  }}
                >
                  {saving ? 'Saving…' : 'Save Changes'}
                </button>
              </>
            )}
          </div>
        </div>
      </div>

      {/* ── STATUS (big pill row when editing) ── */}
      {editing && (
        <div style={{ marginBottom: 24, padding: '20px 28px', background: 'rgba(255,153,51,0.05)', border: '1px solid rgba(255,153,51,0.15)', borderRadius: 16 }}>
          <p style={{ fontSize: '0.58rem', fontWeight: 700, letterSpacing: '0.22em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.35)', marginBottom: 14 }}>Update Status</p>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 10 }}>
            {Object.entries(STATUSES_MAP).map(([val, s]) => (
              <button key={val} onClick={() => setStatus(val)} style={{
                padding: '10px 20px', borderRadius: 'var(--radius-pill)',
                border: `2px solid ${status === val ? s.color : 'rgba(255,255,255,0.1)'}`,
                background: status === val ? `${s.color}20` : 'transparent',
                color: status === val ? s.color : 'rgba(255,255,255,0.5)',
                fontSize: '0.78rem', fontWeight: 700, letterSpacing: '0.1em',
                textTransform: 'uppercase', cursor: 'pointer', transition: 'all 0.2s',
              }}>
                {s.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* ── Institutional Context ── */}
      <Card title="Institutional Intelligence">
        <Field label="Client Organization" span>
          <p style={{ ...readVal, fontSize: '1.2rem', fontFamily: 'var(--font-serif)', color: 'var(--saffron)' }}>
            {account?.account_name || 'Individual Entity'}
          </p>
        </Field>
        <Field label="Corporate Identity (CIN)">
          <p style={account?.cin_number ? readVal : empty}>{account?.cin_number || 'N/A'}</p>
        </Field>
        <Field label="Tax Identity (PAN)">
          <p style={account?.pan_number ? readVal : empty}>{account?.pan_number || 'N/A'}</p>
        </Field>
        <Field label="GST Registration" span>
          <p style={account?.gstin_number ? readVal : empty}>{account?.gstin_number || 'Not provided'}</p>
        </Field>
      </Card>

      {/* ── Service & Request Info ── */}
      <Card title="Service Blueprint">
        <Field label="Primary Pillar" span>
          {editing ? (
            <select value={service} onChange={e => setService(e.target.value)} style={{ ...inp, appearance: 'none', cursor: 'pointer' }}>
              {SERVICE_NAMES.map(n => <option key={n}>{n}</option>)}
            </select>
          ) : (
            <p style={{ ...readVal, fontWeight: 600 }}>{service || '—'}</p>
          )}
        </Field>

        {record.opted_sub_services?.length > 0 && (
          <Field label="Tactical Sub-Services" span>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
              {record.opted_sub_services.map((s: string) => (
                <span key={s} style={{ fontSize: '0.72rem', fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', padding: '6px 14px', background: 'rgba(255,255,255,0.03)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 'var(--radius-pill)', color: 'rgba(255,255,255,0.4)' }}>
                  {s}
                </span>
              ))}
            </div>
          </Field>
        )}

        <Field label="Brief & Context" span>
          {editing ? (
            <textarea value={record.description} onChange={e => setRecord({ ...record, description: e.target.value })} style={{ ...inp, minHeight: 120, resize: 'vertical' }} />
          ) : (
            <p style={{ ...readVal, color: 'rgba(255,255,255,0.65)', lineHeight: 1.8 }}>{record.description || 'No detailed description provided.'}</p>
          )}
        </Field>
      </Card>

      {/* ── Operational Alignment ── */}
      <Card title="Operational Tracking">
        <Field label="Lead Counsel">
          {editing ? (
            <input type="text" value={assignedTo} onChange={e => setAssignedTo(e.target.value)} placeholder="Assign to personnel..." style={inp} />
          ) : (
            <p style={assignedTo ? readVal : empty}>{assignedTo || 'Unassigned'}</p>
          )}
        </Field>

        <Field label="Strategic Priority">
          <p style={{ ...readVal, color: priorityColor, fontWeight: 700 }}>{priority}</p>
        </Field>

        <Field label="Deadlines & Milestones">
          {editing ? (
            <input type="date" value={dueDate} onChange={e => setDueDate(e.target.value)} style={inp} />
          ) : (
            <p style={dueDate ? readVal : empty}>{dueDate ? fmt(dueDate) : 'Open-ended mandate'}</p>
          )}
        </Field>

        <Field label="Engagement Value">
          <p style={{ ...readVal, color: 'var(--gold)', fontWeight: 600 }}>TBD — Scoping in Progress</p>
        </Field>
      </Card>

      {/* ── Activity History (Timeline) ── */}
      <Card title="Activity & Audit Logs">
        <div style={{ display: 'flex', flexDirection: 'column', gap: 20, gridColumn: '1 / -1' }}>
          {history.length > 0 ? (
            <>
              {(showAllHistory ? history : history.slice(0, 5)).map((h: any) => (
                <div key={h.id} style={{ display: 'flex', gap: 16, alignItems: 'flex-start' }}>
                  <div style={{ width: 12, height: 12, borderRadius: '50%', background: 'var(--saffron)', marginTop: 4, flexShrink: 0, boxShadow: '0 0 10px var(--saffron)' }} />
                  <div>
                    <p style={{ fontSize: '0.85rem', color: 'white', lineHeight: 1.5 }}>
                      <strong style={{ color: 'var(--saffron)' }}>{h.changed_by_name}</strong> updated
                      <span style={{ color: 'rgba(255,255,255,0.4)', margin: '0 6px' }}>{h.field_name}</span>
                      from <em style={{ color: '#ef4444', fontStyle: 'normal' }}>"{h.old_value}"</em>
                      to <em style={{ color: '#22c55e', fontStyle: 'normal' }}>"{h.new_value}"</em>
                    </p>
                    <p style={{ fontSize: '0.65rem', color: 'rgba(255,255,255,0.25)', marginTop: 4 }}>
                      {new Date(h.created_at || h.changed_at).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
                    </p>
                  </div>
                </div>
              ))}

              {history.length > 5 && (
                <button
                  type="button"
                  onClick={() => setShowAllHistory(!showAllHistory)}
                  style={{
                    background: 'none', border: 'none', color: 'var(--saffron)',
                    fontSize: '0.75rem', fontWeight: 700, letterSpacing: '0.1em',
                    textTransform: 'uppercase', cursor: 'pointer', textAlign: 'left',
                    padding: '10px 0', marginTop: 10, display: 'inline-flex', alignItems: 'center', gap: 8
                  }}
                >
                  {showAllHistory ? 'Show Recent Changes' : `View All Activity (${history.length})`}
                  <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <polyline points={showAllHistory ? "18 15 12 9 6 15" : "6 9 12 15 18 9"} />
                  </svg>
                </button>
              )}
            </>
          ) : (
            <p style={{ ...empty, padding: '20px 0' }}>No modifications recorded for this mandate.</p>
          )}
        </div>
      </Card>

    </div>
  );
};

export default MandateDetail;
