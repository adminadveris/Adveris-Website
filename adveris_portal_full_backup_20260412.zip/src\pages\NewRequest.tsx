import React, { useState } from 'react';
import { servicesData } from '../data/servicesData';
import { mockApi } from '../lib/mockApi';
import { useNavigate } from 'react-router-dom';

type Step = 'pan' | 'register' | 'scoping' | 'spec';

const NewRequest = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>('pan');
  const [pan, setPan] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Account Data (Found or Newly Entered)
  const [accountName, setAccountName] = useState('');
  const [cin, setCin] = useState('');
  const [gstin, setGstin] = useState('');
  const [accountId, setAccountId] = useState<string | null>(null);

  // Service Data
  const [selectedService, setSelectedService] = useState('');
  const [optedServices, setOptedServices] = useState<string[]>([]);
  const [additionalInfo, setAdditionalInfo] = useState('');
  const [success, setSuccess] = useState(false);

  const handlePanCheck = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!pan) return;
    setLoading(true);
    setError('');
    
    try {
      const accounts = await mockApi.getAccounts();
      const existing = accounts.find((a: any) => a.pan_number?.toUpperCase() === pan.toUpperCase());
      
      if (existing) {
        setAccountId(existing.id);
        setAccountName(existing.account_name);
        setStep('scoping');
      } else {
        setStep('register');
      }
    } catch (err) {
      setError('System verification error. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (!accountName) return;
    setStep('scoping');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      // 1. Create account if NEW
      let finalAccountId = accountId;
      if (!finalAccountId) {
        const newAcc = await mockApi.createAccount({
          account_name: accountName,
          pan_number: pan,
          cin_number: cin,
          gstin_number: gstin
        });
        finalAccountId = newAcc.id;
      }

      // 2. Create mandate
      await mockApi.createRecord({
        account_id: finalAccountId,
        account_name: accountName,
        title: selectedService,
        primary_service: selectedService,
        opted_sub_services: optedServices,
        additional_requirements: additionalInfo
      });

      setSuccess(true);
      setTimeout(() => navigate('/dashboard/records'), 1800);
    } catch (err: any) {
      setError(err.message || 'Submission failed');
    } finally {
      setLoading(false);
    }
  };

  if (success) {
    return (
      <div className="portal-content portal-success-stage">
        <div className="success-icon-wrap">
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="20 6 9 17 4 12"/></svg>
        </div>
        <h2>Mandate <em>Initialized</em></h2>
        <p>Your strategic request has been logged successfully.</p>
      </div>
    );
  }

  return (
    <div className="portal-content">
      {/* HEADER SECTION (EXACT TYPOGRAPHY) */}
      <div className="portal-page-header-row">
        <div>
          <h1 className="serif-title">Service <em>Request</em></h1>
          <p className="subtitle">Initiate a new strategic mandate with the firm.</p>
        </div>
        <div className="step-tracker">
          <span className={step === 'pan' || step === 'register' ? 'active' : ''}>01 / IDENTITY</span>
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="9 18 15 12 9 6"/></svg>
          <span className={step === 'scoping' || step === 'spec' ? 'active' : ''}>02 / SCOPING</span>
        </div>
      </div>

      <div className="portal-request-grid-center">
        
        {/* STEP 1: PAN CHECK */}
        {step === 'pan' && (
          <div className="portal-auth-card">
            <h2 className="card-title">Identify <em>Account</em></h2>
            <p className="card-sub">Please enter the Permanent Account Number (PAN) of the institutional entity you are requesting services for.</p>
            
            {error && (
              <div className="portal-error-msg mt-24" style={{ marginBottom: 0 }}>
                {error}
              </div>
            )}

            <form onSubmit={handlePanCheck} className="mt-32">
              <div className="portal-form-group">
                <label className="portal-form-label">PAN Number</label>
                <input 
                  required
                  type="text" 
                  className="portal-form-control pan-input" 
                  placeholder="ABCDE1234F"
                  value={pan}
                  onChange={e => setPan(e.target.value.toUpperCase())}
                />
              </div>
              <button disabled={loading || !pan} type="submit" className="btn-portal-saffron w-full mt-16">
                {loading ? 'Verifying...' : 'Confirm Entity Identity'}
              </button>
            </form>
          </div>
        )}

        {/* STEP 1B: REGISTRATION (SCREENSHOT-EXACT) */}
        {step === 'register' && (
          <div className="portal-auth-card register-width">
            <h2 className="card-title">New Entity <em>Registration</em></h2>
            
            {/* Identity Warning Alert */}
            <div className="portal-alert-orange">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ marginTop: 2 }}><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
              <p>Identity not found in database. Please provide legal entity details to continue.</p>
            </div>

            <form onSubmit={handleRegister} className="mt-24">
              <div className="portal-form-group">
                <label className="portal-form-label">FULL LEGAL ACCOUNT NAME</label>
                <input 
                  required
                  type="text" 
                  className="portal-form-control" 
                  placeholder="e.g. Adveris Advisors LLP"
                  value={accountName}
                  onChange={e => setAccountName(e.target.value)}
                />
              </div>

              <div className="portal-form-grid-2">
                <div className="portal-form-group">
                  <label className="portal-form-label">REGISTRATION NUMBER (CIN/LLPIN)</label>
                  <input 
                    type="text" 
                    className="portal-form-control" 
                    placeholder="e.g. U123..."
                    value={cin}
                    onChange={e => setCin(e.target.value)}
                  />
                </div>
                <div className="portal-form-group">
                  <label className="portal-form-label">GSTIN NUMBER</label>
                  <input 
                    type="text" 
                    className="portal-form-control" 
                    placeholder="e.g. 29AAB..."
                    value={gstin}
                    onChange={e => setGstin(e.target.value)}
                  />
                </div>
              </div>

              <div className="portal-form-actions-split mt-32">
                <button type="button" onClick={() => setStep('pan')} className="btn-portal-outline">BACK</button>
                <button type="submit" className="btn-portal-saffron-solid">CONTINUE TO SCOPING</button>
              </div>
            </form>
          </div>
        )}

        {/* STEP 2: SCOPING */}
        {step === 'scoping' && (
          <div className="portal-auth-card scoping-width">
            <h2 className="card-title">Portfolio <em>Scoping</em></h2>
            <p className="card-sub mb-24">Define the scope for <strong>{accountName}</strong></p>
            
            <form onSubmit={handleSubmit}>
              <div className="portal-form-group">
                <label className="portal-form-label">Primary Service Area</label>
                <select 
                  required
                  className="portal-form-control"
                  value={selectedService}
                  onChange={e => { setSelectedService(e.target.value); setOptedServices([]); }}
                >
                  <option value="">Select Domain...</option>
                  {servicesData.map(s => <option key={s.id} value={s.name}>{s.name}</option>)}
                </select>
              </div>

              <div className="portal-form-group">
                <label className="portal-form-label">Detailed Requirements</label>
                <textarea 
                  className="portal-form-control min-h-120" 
                  placeholder="Detail the nuances of this mandate..."
                  value={additionalInfo}
                  onChange={e => setAdditionalInfo(e.target.value)}
                />
              </div>

              <div className="portal-form-actions-split mt-24">
                <button type="button" onClick={() => setStep(accountId ? 'pan' : 'register')} className="btn-portal-outline">BACK</button>
                <button type="submit" className="btn-portal-saffron-solid">INITIALIZE MANDATE</button>
              </div>
            </form>
          </div>
        )}
      </div>
    </div>
  );
};

export default NewRequest;
