import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { mockApi } from '../lib/mockApi';
import { ClientModal, AccountModal } from '../components/CRMModals';

// ─── Inlined compact table for related lists ──────────────────────
interface ColDef { header: string; key: string; render?: (row: any) => React.ReactNode; }

const CompactTable = ({ cols, rows, onRowClick, emptyMsg = 'No records.' }: { cols: ColDef[]; rows: any[]; onRowClick?: (row: any) => void; emptyMsg?: string }) => (
  <div style={{ background: 'rgba(255,255,255,0.02)', border: '1px solid rgba(255,255,255,0.05)', overflow: 'hidden', borderRadius: 8 }}>
    <table style={{ borderCollapse: 'collapse', width: '100%' }}>
      <thead>
        <tr style={{ background: 'rgba(255,255,255,0.03)' }}>
          {cols.map(c => (
            <th key={c.key} style={{ padding: '10px 16px', textAlign: 'left', fontSize: '0.62rem', fontWeight: 700, letterSpacing: '0.15em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.35)', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
              {c.header}
            </th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.length > 0 ? rows.map((row, i) => (
          <tr key={row.id ?? i} onClick={() => onRowClick?.(row)} style={{ borderBottom: '1px solid rgba(255,255,255,0.04)', cursor: onRowClick ? 'pointer' : 'default' }}>
            {cols.map(c => (
              <td key={c.key} style={{ padding: '12px 16px', fontSize: '0.85rem', color: 'rgba(255,255,255,0.75)' }}>
                {c.render ? c.render(row) : (row[c.key] ?? '—')}
              </td>
            ))}
          </tr>
        )) : (
          <tr><td colSpan={cols.length} style={{ padding: 40, textAlign: 'center', color: 'rgba(255,255,255,0.2)', fontSize: '0.85rem', fontStyle: 'italic' }}>{emptyMsg}</td></tr>
        )}
      </tbody>
    </table>
  </div>
);
// ─────────────────────────────────────────────────────────────────

const AccountDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [account, setAccount] = useState<any>(null);
  const [clients, setClients] = useState<any[]>([]);
  const [history, setHistory] = useState<any[]>([]);
  const [showAllHistory, setShowAllHistory] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showAccountEdit, setShowAccountEdit] = useState(false);
  const [showAddClient, setShowAddClient] = useState(false);

  const load = async () => {
    if (!id) return;
    setLoading(true);
    const [acc, clis, hist] = await Promise.all([
      mockApi.getAccountById(id),
      mockApi.getClientsByAccount(id),
      mockApi.getHistoryByRecord(id)
    ]);
    if (!acc) { navigate('/dashboard/crm'); return; }
    setAccount(acc);
    setClients(clis);
    setHistory(hist);
    setLoading(false);
  };

  useEffect(() => { load(); }, [id]);

  if (loading) return <div style={{ padding: 80, textAlign: 'center', color: 'rgba(255,255,255,0.3)' }}>Loading Legal Entity...</div>;

  const clientCols: ColDef[] = [
    { header: 'Name', key: 'client_name', render: r => <div><div style={{ fontWeight: 600, color: 'white' }}>{r.client_name}</div><div style={{ fontSize: '0.72rem', color: 'rgba(255,255,255,0.35)' }}>{r.designation}</div></div> },
    { header: 'Email', key: 'email_1' },
    { header: 'Phone', key: 'phone_1' },
  ];

  const Field = ({ label, value }: { label: string; value?: string }) => (
    <div style={{ marginBottom: 28, paddingBottom: 20, borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
      <p style={{ fontSize: '0.6rem', fontWeight: 700, letterSpacing: '0.15em', textTransform: 'uppercase', color: 'rgba(255,153,51,0.55)', marginBottom: 8 }}>{label}</p>
      <p style={{ fontSize: '1.05rem', color: value ? 'white' : 'rgba(255,255,255,0.2)', fontStyle: value ? 'normal' : 'italic' }}>{value || 'Not provided'}</p>
    </div>
  );

  return (
    <div className="portal-content-wide">
      {showAccountEdit && <AccountModal account={account} onClose={() => setShowAccountEdit(false)} onSaved={load} />}
      {showAddClient && <ClientModal fixedAccountId={account.id} onClose={() => setShowAddClient(false)} onSaved={load} />}

      {/* Header */}
      <div className="portal-page-header" style={{ marginBottom: 40 }}>
        <button onClick={() => navigate('/dashboard/crm')} 
          style={{ background: 'transparent', border: 'none', color: 'rgba(255,255,255,0.4)', fontSize: '0.75rem', fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8, marginBottom: 20, padding: 0 }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="15 18 9 12 15 6" /></svg>
          Back to Hub
        </button>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: 16 }}>
          <div>
            <p style={{ fontSize: '0.6rem', fontWeight: 700, letterSpacing: '0.22em', color: 'var(--saffron)', marginBottom: 6, textTransform: 'uppercase' }}>Legal Entity</p>
            <h1 style={{ fontFamily: 'var(--font-serif)', fontSize: 'clamp(1.8rem,4vw,2.6rem)', color: 'white', fontWeight: 400 }}>{account.account_name}</h1>
            {account.industry && <p style={{ color: 'rgba(255,255,255,0.4)', fontSize: '0.9rem', marginTop: 4 }}>{account.industry}</p>}
          </div>
          <button onClick={() => setShowAccountEdit(true)} 
            style={{ padding: '10px 24px', background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 'var(--radius-pill)', color: 'white', fontSize: '0.7rem', fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', cursor: 'pointer' }}>
            Edit Entity
          </button>
        </div>
      </div>

      {/* 6 core components */}
      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 3fr) minmax(0, 2fr)', gap: 40, alignItems: 'start' }}>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 32 }}>
          {/* LEFT: Account Details (60%) */}
          <div className="portal-panel" style={{ padding: 40 }}>
            <h3 style={{ fontSize: '0.7rem', fontWeight: 700, letterSpacing: '0.15em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.4)', marginBottom: 32 }}>Institutional Intelligence</h3>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 32px' }}>
              <Field label="Registration (CIN / LLPIN)" value={account.cin_number} />
              <Field label="PAN Number" value={account.pan_number} />
              <Field label="GSTIN" value={account.gstin_number} />
              <Field label="Industry / Sector" value={account.industry} />
            </div>
          </div>

          {/* Change Log */}
          <div className="portal-panel" style={{ padding: 40 }}>
            <h3 style={{ fontSize: '0.75rem', fontWeight: 700, letterSpacing: '0.15em', textTransform: 'uppercase', color: 'white', marginBottom: 24 }}>Institutional Change Log</h3>
            {history.length > 0 ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                {(showAllHistory ? history : history.slice(0, 5)).map((log) => (
                  <div key={log.id} style={{ display: 'flex', gap: 16, padding: '16px', background: 'rgba(255,255,255,0.02)', borderRadius: 'var(--radius-sm)', borderLeft: `3px solid ${log.action === 'CREATE' ? '#22c55e' : 'var(--saffron)'}` }}>
                    <div style={{ flex: 1 }}>
                      <p style={{ fontSize: '0.8rem', color: 'white', fontWeight: 500 }}>
                        {log.action === 'CREATE' ? 'Entity Registered' : `Updated ${log.field_name}`}
                      </p>
                      <p style={{ fontSize: '0.7rem', color: 'rgba(255,255,255,0.4)', marginTop: 4 }}>
                        {log.action === 'UPDATE' && <span>Value adjusted from <strong style={{ color: 'rgba(255,255,255,0.6)' }}>{log.old_value}</strong> to <strong style={{ color: 'var(--saffron)' }}>{log.new_value}</strong></span>}
                      </p>
                      <div style={{ display: 'flex', gap: 12, marginTop: 8, fontSize: '0.65rem', color: 'rgba(255,255,255,0.3)' }}>
                        <span>By {log.changed_by_name}</span>
                        <span>•</span>
                        <span>{new Date(log.created_at).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                    </div>
                  </div>
                ))}

                {history.length > 5 && (
                  <button
                    onClick={() => setShowAllHistory(!showAllHistory)}
                    style={{
                      background: 'none', border: 'none', color: 'var(--saffron)',
                      fontSize: '0.72rem', fontWeight: 700, letterSpacing: '0.1em',
                      textTransform: 'uppercase', cursor: 'pointer', textAlign: 'left',
                      padding: '8px 0', marginTop: 8, display: 'inline-flex', alignItems: 'center', gap: 8
                    }}
                  >
                    {showAllHistory ? 'Show Recent Changes' : `View All Activity (${history.length})`}
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <polyline points={showAllHistory ? "18 15 12 9 6 15" : "6 9 12 15 18 9"} />
                    </svg>
                  </button>
                )}
              </div>
            ) : (
              <p style={{ fontSize: '0.8rem', color: 'rgba(255,255,255,0.2)', fontStyle: 'italic' }}>No historical updates found for this entity.</p>
            )}
          </div>
        </div>

        {/* RIGHT: Related Clients (40%) */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <h3 style={{ fontSize: '0.7rem', fontWeight: 700, letterSpacing: '0.15em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.4)' }}>
              Professional Contacts <span style={{ color: 'var(--saffron)' }}>({clients.length})</span>
            </h3>
            <button onClick={() => setShowAddClient(true)} 
              style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '7px 16px', background: 'var(--saffron)', color: 'var(--navy)', border: 'none', borderRadius: 'var(--radius-pill)', fontSize: '0.65rem', fontWeight: 700, textTransform: 'uppercase', cursor: 'pointer' }}>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>
              Create Client
            </button>
          </div>
          <CompactTable 
            cols={clientCols} 
            rows={clients} 
            onRowClick={(r) => navigate(`/dashboard/crm/client/${r.id}`)}
            emptyMsg="No contacts linked yet. Click 'Create Client' to add one." 
          />
        </div>
      </div>
    </div>
  );
};

export default AccountDetail;
