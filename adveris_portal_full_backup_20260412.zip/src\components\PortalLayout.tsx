import React from 'react';
import { NavLink } from 'react-router-dom';
import { supabase } from '../lib/supabaseClient';

const PortalLayout = ({ children, profile }: { children: React.ReactNode, profile: any }) => {


  const handleLogout = async () => {
    localStorage.removeItem('adveris_mock_session');
    await supabase.auth.signOut();
    window.location.href = '/';
  };

  const subNavItems = [
    { name: 'Overview', path: '/dashboard/overview', roles: ['admin', 'employee'] },
    { name: 'New Request', path: '/dashboard/new-request', roles: ['client', 'admin'] },
    { name: 'Firm Mandates', path: '/dashboard/records', roles: ['admin', 'employee'] },
    { name: 'My Mandates', path: '/dashboard/records', roles: ['client'] },
    { name: 'Timesheets', path: '/dashboard/timesheets', roles: ['admin', 'employee'] },
    { name: 'Expenses', path: '/dashboard/expenses', roles: ['admin', 'employee'] },
    { name: 'Accounts & Clients', path: '/dashboard/crm', roles: ['admin', 'employee'] },
    { name: 'Action Logs', path: '/dashboard/service-hub', roles: ['admin'] },
  ].filter(item => item.roles.includes(profile.role));

  return (
    <div className="portal-aura-container">
      {/* AURORA BLOBS — Atmospheric Glowing Effect */}
      <div className="portal-aurora-bg" aria-hidden="true">
        <div className="aurora-blob aurora-blob-1"></div>
        <div className="aurora-blob aurora-blob-2"></div>
      </div>

      {/* TIER 1: BRAND & PRIMARY ACTIONS (SCREENSHOT-EXACT) */}
      <header className="portal-header-top">
        <div className="portal-header-inner-wrap">
          <div className="portal-brand-lockup">
            <span className="brand-main">Adveris</span>
            <span className="brand-firm">FIRM</span>
            <span className="brand-divider">—</span>
            <span className="brand-portal">CLIENT PORTAL</span>
          </div>

          <div className="portal-header-actions-right">
            <div className="portal-admin-indicator">
              <span className="dot"></span>
              {profile.role.toUpperCase()}
            </div>
            <button onClick={handleLogout} className="portal-action-link">SIGN OUT</button>
            <button className="portal-action-link">MENU</button>
            <button className="portal-plus-btn">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <line x1="12" y1="5" x2="12" y2="19"></line>
                <line x1="5" y1="12" x2="19" y2="12"></line>
              </svg>
            </button>
          </div>
        </div>
      </header>

      {/* TIER 2: NAVIGATION PILLS (SCREENSHOT-EXACT) */}
      <nav className="portal-nav-row">
        <div className="portal-nav-pills-centered">
          {subNavItems.map(item => (
            <NavLink
              key={item.path}
              to={item.path}
              end={item.path === '/dashboard/overview'}
              className={({ isActive }) => 
                `portal-nav-pill-v2 ${isActive ? 'active' : ''}`
              }
            >
              {item.name}
            </NavLink>
          ))}
        </div>
      </nav>

      <main className="portal-main-stage">
        <div className="container">
          {children}
        </div>
      </main>
      
      {/* FOOTER (Mirrors index.html) */}
      <footer style={{ marginTop: 'auto', position: 'relative', zIndex: 10 }}>
        <div className="footer-saffron-bar"></div>
        <div className="container" style={{ paddingTop: 72 }}>
          <div className="footer-grid">
            <div className="footer-brand">
              <div className="nav__logo" style={{ marginBottom: 16 }}>
                <span className="logo-name" style={{ fontFamily: 'var(--font-serif)', fontSize: '1.8rem', color: 'white' }}>Adveris</span>
                <span className="logo-tagline" style={{ color: 'rgba(255,255,255,0.45)' }}>Advisors LLP</span>
              </div>
              <p>Your Trusted Advisory Partner in India. Expert legal, compliance and company secretary services — delivered with integrity.</p>
            </div>
            <div className="footer-col">
              <h4>Support</h4>
              <a href="mailto:csashikgswamy@gmail.com">Help Desk</a>
              <a href="#">Knowledge Base</a>
            </div>
            <div className="footer-col">
              <h4>Firm</h4>
              <a href="/about.html">About Us</a>
              <a href="/team.html">Our Team</a>
              <a href="/contact.html">Contact</a>
            </div>
            <div className="footer-col">
              <h4>Contact</h4>
              <a href="tel:+919739382704">+91 97393 82704</a>
              <a href="mailto:csashikgswamy@gmail.com">csashikgswamy@gmail.com</a>
              <a href="https://www.google.com/maps/search/?api=1&query=Om+Chambers+648/A,+4th+Flr+Binnamangala+1st+stg+Indiranagar+Bengaluru+560038" target="_blank" rel="noopener noreferrer">Om Chambers 648/A, Indiranagar</a>
              <a href="https://www.google.com/maps/search/?api=1&query=Om+Chambers+648/A,+4th+Flr+Binnamangala+1st+stg+Indiranagar+Bengaluru+560038" target="_blank" rel="noopener noreferrer">Bengaluru — 560038</a>
            </div>
          </div>
          <div className="footer-bottom">
            <span>© 2024 Adveris Advisors LLP. All rights reserved.</span>
            <span>Bengaluru, Karnataka, India</span>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default PortalLayout;
