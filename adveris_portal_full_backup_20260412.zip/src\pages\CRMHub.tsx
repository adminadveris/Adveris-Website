import React, { useState, useEffect, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { mockApi } from '../lib/mockApi';
import { AccountModal, ClientModal } from '../components/CRMModals';

// ─── Inlined sortable/searchable table ───────────────────────────
interface ColDef {
  header: string;
  key: string;
  render?: (row: any) => React.ReactNode;
}

const DataTable = ({
  cols, rows, onRowClick, searchPlaceholder = 'Search...',
}: {
  cols: ColDef[];
  rows: any[];
  onRowClick?: (row: any) => void;
  searchPlaceholder?: string;
}) => {
  const [q, setQ] = useState('');
  const [sortKey, setSortKey] = useState('');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');

  const filtered = useMemo(() => {
    if (!q) return rows;
    const lq = q.toLowerCase();
    return rows.filter(r => Object.values(r).some(v => String(v ?? '').toLowerCase().includes(lq)));
  }, [rows, q]);

  const sorted = useMemo(() => {
    if (!sortKey) return filtered;
    return [...filtered].sort((a, b) => {
      if (a[sortKey] === b[sortKey]) return 0;
      const r = a[sortKey] > b[sortKey] ? 1 : -1;
      return sortDir === 'asc' ? r : -r;
    });
  }, [filtered, sortKey, sortDir]);

  const handleSort = (key: string) => {
    if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('asc'); }
  };

  return (
    <div>
      <div style={{ position: 'relative', marginBottom: 20 }}>
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.25)" strokeWidth="2"
          style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none' }}>
          <circle cx="11" cy="11" r="8" /><line x1="21" y1="21" x2="16.65" y2="16.65" />
        </svg>
        <input value={q} onChange={e => setQ(e.target.value)} placeholder={searchPlaceholder}
          style={{ background: 'rgba(255,255,255,0.04)', border: '1.5px solid rgba(255,255,255,0.08)', borderRadius: 8, padding: '10px 18px 10px 38px', color: 'white', fontSize: '0.85rem', outline: 'none', width: '100%', maxWidth: 340, fontFamily: 'inherit' }} />
      </div>
      <div style={{ background: 'rgba(255,255,255,0.02)', borderRadius: 12, border: '1px solid rgba(255,255,255,0.05)', overflow: 'hidden' }}>
        <table style={{ borderCollapse: 'collapse', width: '100%' }}>
          <thead>
            <tr style={{ background: 'rgba(255,255,255,0.03)' }}>
              {cols.map(col => (
                <th key={col.key} onClick={() => handleSort(col.key)}
                  style={{ padding: '14px 24px', textAlign: 'left', fontSize: '0.65rem', fontWeight: 700, letterSpacing: '0.15em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.4)', borderBottom: '1px solid rgba(255,255,255,0.08)', cursor: 'pointer', userSelect: 'none', whiteSpace: 'nowrap' }}>
                  <span>{col.header}</span>
                  {sortKey === col.key && <span style={{ marginLeft: 4, opacity: 0.5 }}>{sortDir === 'asc' ? '↑' : '↓'}</span>}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sorted.length > 0 ? sorted.map((row, i) => (
              <tr key={row.id ?? i} onClick={() => onRowClick?.(row)}
                style={{ cursor: onRowClick ? 'pointer' : 'default', borderBottom: '1px solid rgba(255,255,255,0.04)', transition: 'background 0.15s' }}
                onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.03)')}
                onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}>
                {cols.map(col => (
                  <td key={col.key} style={{ padding: '18px 24px', fontSize: '0.88rem', color: 'rgba(255,255,255,0.8)' }}>
                    {col.render ? col.render(row) : (row[col.key] ?? '—')}
                  </td>
                ))}
              </tr>
            )) : (
              <tr>
                <td colSpan={cols.length} style={{ padding: 60, textAlign: 'center', color: 'rgba(255,255,255,0.2)', fontSize: '0.88rem', fontStyle: 'italic' }}>
                  No records found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
// ─────────────────────────────────────────────────────────────────

type Tab = 'accounts' | 'clients';

const CRMHub = () => {
  const [tab, setTab] = useState<Tab>('accounts');
  const [accounts, setAccounts] = useState<any[]>([]);
  const [clients, setClients] = useState<any[]>([]);
  const [showAccountModal, setShowAccountModal] = useState(false);
  const [showClientModal, setShowClientModal] = useState(false);
  const navigate = useNavigate();

  const load = async () => {
    const [accs, clis] = await Promise.all([mockApi.getAccounts(), mockApi.getClients()]);
    setAccounts(accs);
    setClients(clis);
  };

  useEffect(() => { load(); }, []);

  const accountCols: ColDef[] = [
    {
      header: 'Account Name', key: 'account_name',
      render: r => (
        <div>
          <div style={{ color: 'white', fontWeight: 600 }}>{r.account_name}</div>
          <div style={{ fontSize: '0.75rem', color: 'rgba(255,153,51,0.7)', marginTop: 2 }}>{r.industry || '—'}</div>
        </div>
      )
    },
    { header: 'Registration #', key: 'registration_num' },
    { header: 'PAN', key: 'pan_number' },
    { header: 'GSTIN', key: 'gst_number' },
    {
      header: '', key: '__action',
      render: () => (
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="2">
          <polyline points="9 18 15 12 9 6" />
        </svg>
      )
    },
  ];

  const clientCols: ColDef[] = [
    {
      header: 'Client Name', key: 'client_name',
      render: r => (
        <div>
          <div style={{ color: 'white', fontWeight: 600 }}>{r.client_name}</div>
          <div style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.35)', marginTop: 2 }}>{r.designation || '—'}</div>
        </div>
      )
    },
    {
      header: 'Account', key: 'account_id',
      render: r => {
        const acc = accounts.find(a => a.id === r.account_id);
        return <span style={{ color: 'rgba(255,153,51,0.8)' }}>{acc?.account_name || '—'}</span>;
      }
    },
    { header: 'Primary Email', key: 'email_1' },
    { header: 'Phone', key: 'phone_1' },
    {
        header: '', key: '__action',
        render: () => (
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.2)" strokeWidth="2">
            <polyline points="9 18 15 12 9 6" />
          </svg>
        )
      },
  ];

  return (
    <div className="portal-content-wide">
      {showAccountModal && <AccountModal onClose={() => setShowAccountModal(false)} onSaved={load} />}
      {showClientModal && <ClientModal onClose={() => setShowClientModal(false)} onSaved={load} />}

      <div className="portal-page-header">
        <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', flexWrap: 'wrap', gap: 20 }}>
          <div>
            <p style={{ fontSize: '0.6rem', fontWeight: 700, letterSpacing: '0.22em', textTransform: 'uppercase', color: 'var(--saffron)', marginBottom: 8 }}>— Firm Relations</p>
            <h1 style={{ fontFamily: 'var(--font-serif)', fontSize: 'clamp(2rem,4vw,3rem)', color: 'white', fontWeight: 400, lineHeight: 1.1 }}>
              Accounts & <em>Clients</em>
            </h1>
            <p style={{ fontSize: '0.88rem', color: 'rgba(255,255,255,0.4)', marginTop: 8 }}>Manage legal entities and their associated professional contacts.</p>
          </div>
          <button onClick={() => tab === 'accounts' ? setShowAccountModal(true) : setShowClientModal(true)}
            style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '13px 28px', background: 'var(--saffron)', color: 'var(--navy)', border: 'none', borderRadius: 'var(--radius-pill)', fontSize: '0.75rem', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', cursor: 'pointer', boxShadow: '0 4px 20px rgba(255,153,51,0.3)' }}>
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" /></svg>
            New {tab === 'accounts' ? 'Account' : 'Client'}
          </button>
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', gap: 4, marginTop: 32, borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
          {(['accounts', 'clients'] as Tab[]).map(t => (
            <button key={t} onClick={() => setTab(t)} style={{
              padding: '12px 24px', border: 'none', cursor: 'pointer', fontSize: '0.72rem', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase',
              background: tab === t ? 'rgba(255,255,255,0.04)' : 'transparent',
              color: tab === t ? 'var(--saffron)' : 'rgba(255,255,255,0.3)',
              borderBottom: tab === t ? '2px solid var(--saffron)' : '2px solid transparent',
              transition: 'all 0.2s ease'
            }}>
              {t}
              <span style={{ marginLeft: 8, fontSize: '0.62rem', background: tab === t ? 'var(--saffron)' : 'rgba(255,255,255,0.1)', color: tab === t ? 'var(--navy)' : 'rgba(255,255,255,0.35)', padding: '2px 8px', borderRadius: 10 }}>
                {t === 'accounts' ? accounts.length : clients.length}
              </span>
            </button>
          ))}
        </div>
      </div>

      <div style={{ marginTop: 24 }}>
        {tab === 'accounts'
          ? <DataTable cols={accountCols} rows={accounts} searchPlaceholder="Search by name, PAN, Reg #..." onRowClick={r => navigate(`/dashboard/crm/account/${r.id}`)} />
          : <DataTable cols={clientCols} rows={clients} searchPlaceholder="Search by name, email, designation..." onRowClick={r => navigate(`/dashboard/crm/client/${r.id}`)} />
        }
      </div>
    </div>
  );
};

export default CRMHub;
