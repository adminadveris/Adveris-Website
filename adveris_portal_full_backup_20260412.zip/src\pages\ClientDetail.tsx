import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { mockApi } from '../lib/mockApi';
import { ClientModal } from '../components/CRMModals';

const ClientDetail = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [client, setClient] = useState<any>(null);
  const [account, setAccount] = useState<any>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [showAllHistory, setShowAllHistory] = useState(false);
  const [loading, setLoading] = useState(true);
  const [showEdit, setShowEdit] = useState(false);

  const load = async () => {
    if (!id) return;
    setLoading(true);
    const c = await mockApi.getClientById(id);
    if (!c) { navigate('/dashboard/crm'); return; }

    const [acc, hist] = await Promise.all([
      mockApi.getAccountById(c.account_id),
      mockApi.getHistoryByRecord(id)
    ]);

    setClient(c);
    setAccount(acc);
    setHistory(hist);
    setLoading(false);
  };

  useEffect(() => { load(); }, [id]);

  if (loading) return <div style={{ padding: 80, textAlign: 'center', color: 'rgba(255,255,255,0.3)' }}>Loading Professional Profile...</div>;

  const DetailField = ({ label, value, icon }: { label: string; value?: string; icon?: React.ReactNode }) => (
    <div style={{ marginBottom: 24 }}>
      <p style={{ fontSize: '0.6rem', fontWeight: 700, letterSpacing: '0.15em', textTransform: 'uppercase', color: 'rgba(255,153,51,0.6)', marginBottom: 6, display: 'flex', alignItems: 'center', gap: 6 }}>
        {icon} {label}
      </p>
      <p style={{ fontSize: '1rem', color: value ? 'white' : 'rgba(255,255,255,0.2)', fontWeight: 400 }}>{value || '—'}</p>
    </div>
  );

  return (
    <div className="portal-content-wide">
      {showEdit && <ClientModal client={client} onClose={() => setShowEdit(false)} onSaved={load} />}

      {/* Header */}
      <div className="portal-page-header" style={{ marginBottom: 40 }}>
        <button onClick={() => navigate('/dashboard/crm')}
          style={{ background: 'transparent', border: 'none', color: 'rgba(255,255,255,0.4)', fontSize: '0.75rem', fontWeight: 600, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 8, marginBottom: 20, padding: 0 }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="15 18 9 12 15 6" /></svg>
          Back to Hub
        </button>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 20 }}>
          <div>
            <p style={{ fontSize: '0.6rem', fontWeight: 700, letterSpacing: '0.22em', textTransform: 'uppercase', color: 'var(--saffron)', marginBottom: 8 }}>
              — Client Profile
            </p>
            <h1 style={{ fontFamily: 'var(--font-serif)', fontSize: 'clamp(2rem, 4vw, 3rem)', color: 'white', fontWeight: 400, lineHeight: 1.1 }}>
              {client.client_name}
            </h1>
            <p style={{ fontSize: '0.9rem', color: 'rgba(255,255,255,0.5)', marginTop: 6 }}>
              {client.designation} at <span style={{ color: 'var(--saffron)', cursor: 'pointer' }} onClick={() => navigate(`/dashboard/crm/account/${account?.id}`)}>{account?.account_name}</span>
            </p>
          </div>
          <button onClick={() => setShowEdit(true)} style={{ padding: '12px 28px', background: 'rgba(255,153,51,0.1)', border: '1px solid var(--saffron)', borderRadius: 'var(--radius-pill)', color: 'var(--saffron)', fontSize: '0.75rem', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', cursor: 'pointer', transition: 'all 0.2s ease' }}>
            Edit Profile
          </button>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.5fr 1fr', gap: 40, alignItems: 'start' }}>
        {/* Left 60%: Contact Details & History */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 32 }}>

          <div className="portal-panel" style={{ padding: 40 }}>
            <h3 style={{ fontSize: '0.75rem', fontWeight: 700, letterSpacing: '0.15em', textTransform: 'uppercase', color: 'white', marginBottom: 32 }}>Contact Intelligence</h3>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0 40px' }}>
              <div>
                <DetailField label="Primary Email" value={client.email_1} icon={<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" /><polyline points="22,6 12,13 2,6" /></svg>} />
                <DetailField label="Secondary Email" value={client.email_2} />
                <DetailField label="Alternate Email" value={client.email_3} />
              </div>
              <div>
                <DetailField label="Primary Mobile" value={client.phone_1} icon={<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="5" y="2" width="14" height="20" rx="2" ry="2" /><line x1="12" y1="18" x2="12" y2="18" /></svg>} />
                <DetailField label="Secondary Mobile" value={client.phone_2} />
                <DetailField label="Landline / Alternate" value={client.phone_3} />
              </div>
            </div>

            <div style={{ marginTop: 12, paddingTop: 32, borderTop: '1px solid rgba(255,255,255,0.06)' }}>
              <DetailField label="Professional Address" value={client.address} icon={<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z" /><circle cx="12" cy="10" r="3" /></svg>} />
            </div>
          </div>

          {/* Change Log */}
          <div className="portal-panel" style={{ padding: 40 }}>
            <h3 style={{ fontSize: '0.75rem', fontWeight: 700, letterSpacing: '0.15em', textTransform: 'uppercase', color: 'white', marginBottom: 24 }}>Record Change Log</h3>
            {history.length > 0 ? (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
                {(showAllHistory ? history : history.slice(0, 5)).map((log) => (
                  <div key={log.id} style={{ display: 'flex', gap: 16, padding: '16px', background: 'rgba(255,255,255,0.02)', borderRadius: 'var(--radius-sm)', borderLeft: `3px solid ${log.action === 'CREATE' ? '#22c55e' : 'var(--saffron)'}` }}>
                    <div style={{ flex: 1 }}>
                      <p style={{ fontSize: '0.8rem', color: 'white', fontWeight: 500 }}>
                        {log.action === 'CREATE' ? 'Record Created' : `Updated ${log.field_name}`}
                      </p>
                      <p style={{ fontSize: '0.7rem', color: 'rgba(255,255,255,0.4)', marginTop: 4 }}>
                        {log.action === 'UPDATE' && <span>Changed from <strong style={{ color: 'rgba(255,255,255,0.6)' }}>{log.old_value}</strong> to <strong style={{ color: 'var(--saffron)' }}>{log.new_value}</strong></span>}
                      </p>
                      <div style={{ display: 'flex', gap: 12, marginTop: 8, fontSize: '0.65rem', color: 'rgba(255,255,255,0.3)' }}>
                        <span>By {log.changed_by_name}</span>
                        <span>•</span>
                        <span>{new Date(log.created_at).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}</span>
                      </div>
                    </div>
                  </div>
                ))}

                {history.length > 5 && (
                  <button
                    onClick={() => setShowAllHistory(!showAllHistory)}
                    style={{
                      background: 'none', border: 'none', color: 'var(--saffron)',
                      fontSize: '0.72rem', fontWeight: 700, letterSpacing: '0.1em',
                      textTransform: 'uppercase', cursor: 'pointer', textAlign: 'left',
                      padding: '8px 0', marginTop: 8, display: 'inline-flex', alignItems: 'center', gap: 8
                    }}
                  >
                    {showAllHistory ? 'Show Recent Changes' : `View All Activity (${history.length})`}
                    <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                      <polyline points={showAllHistory ? "18 15 12 9 6 15" : "6 9 12 15 18 9"} />
                    </svg>
                  </button>
                )}
              </div>
            ) : (
              <p style={{ fontSize: '0.8rem', color: 'rgba(255,255,255,0.2)', fontStyle: 'italic' }}>No historical changes recorded yet.</p>
            )}
          </div>
        </div>

        {/* Right 40%: Relationship Context */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
          <div className="portal-panel" style={{ padding: 32 }}>
            <h4 style={{ fontSize: '0.65rem', fontWeight: 700, letterSpacing: '0.18em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.4)', marginBottom: 20 }}>Associated Account</h4>
            <div style={{ padding: 24, background: 'rgba(255,153,51,0.05)', borderRadius: 'var(--radius-sm)', border: '1.5px solid rgba(255,153,51,0.1)' }}>
              <p style={{ fontSize: '1.1rem', color: 'white', fontWeight: 600 }}>{account?.account_name}</p>
              <p style={{ fontSize: '0.75rem', color: 'var(--saffron)', marginTop: 4 }}>{account?.industry}</p>
              <button
                onClick={() => navigate(`/dashboard/crm/account/${account?.id}`)}
                style={{ marginTop: 20, width: '100%', padding: '10px', background: 'rgba(255,255,255,0.05)', border: '1px solid rgba(255,255,255,0.1)', color: 'white', fontSize: '0.7rem', fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase', cursor: 'pointer', borderRadius: 'var(--radius-pill)' }}
              >
                View Account Details
              </button>
            </div>
          </div>

          <div style={{ padding: 24, borderRadius: 'var(--radius)', border: '1px dashed rgba(255,255,255,0.1)', textAlign: 'center' }}>
            <p style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.3)', lineHeight: 1.5 }}>
              This profile is part of the Firm's CRM. All internal communications and service requests related to this individual are tracked centrally.
            </p>
          </div>
        </div>

      </div>
    </div>
  );
};

export default ClientDetail;
