import React, { useEffect, useState } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import PortalLayout from '../components/PortalLayout';
import NewRequest from './NewRequest';
import RecordsList from './RecordsList';
import MandateDetail from './MandateDetail';
import AuditLogs from './AuditLogs';
import CRMHub from './CRMHub';
import AccountDetail from './AccountDetail';
import ClientDetail from './ClientDetail';
import * as XLSX from 'xlsx';
import { mockApi } from '../lib/mockApi';
import SearchableSelect from '../components/SearchableSelect';
import { motion, AnimatePresence } from 'framer-motion';

const exportToExcel = (data: any[], filename: string) => {
  const worksheet = XLSX.utils.json_to_sheet(data);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");
  XLSX.writeFile(workbook, `${filename}.xlsx`);
};

const filterDataByRange = (data: any[], rangeKey: string) => {
  const now = new Date();
  const start = new Date();

  switch (rangeKey) {
    case 'last_week':
      start.setDate(now.getDate() - 7);
      return data.filter(d => new Date(d.date) >= start);
    case 'prev_month': {
      const prevMonthStart = new Date(now.getFullYear(), now.getMonth() - 1, 1);
      const prevMonthEnd = new Date(now.getFullYear(), now.getMonth(), 0);
      return data.filter(d => {
        const dd = new Date(d.date);
        return dd >= prevMonthStart && dd <= prevMonthEnd;
      });
    }
    case 'last_3m':
      start.setMonth(now.getMonth() - 3);
      return data.filter(d => new Date(d.date) >= start);
    case 'last_6m':
      start.setMonth(now.getMonth() - 6);
      return data.filter(d => new Date(d.date) >= start);
    case 'last_1y':
      start.setFullYear(now.getFullYear() - 1);
      return data.filter(d => new Date(d.date) >= start);
    default:
      return data;
  }
};

const ExportDropdown = ({ data, filename }: { data: any[], filename: string }) => {
  const [open, setOpen] = useState(false);

  const ranges = [
    { label: 'Last Week', key: 'last_week' },
    { label: 'Previous Month', key: 'prev_month' },
    { label: 'Last 3 Months', key: 'last_3m' },
    { label: 'Last 6 Months', key: 'last_6m' },
    { label: 'Last 1 Year', key: 'last_1y' },
    { label: 'All Records', key: 'all' },
  ];

  const handleExport = (range: string, label: string) => {
    const filtered = filterDataByRange(data, range);
    exportToExcel(filtered, `${filename}_${label.replace(/ /g, '_')}`);
    setOpen(false);
  };

  return (
    <div style={{ position: 'relative' }}>
      <button 
        onClick={() => setOpen(!open)}
        className="btn-portal-outline"
        style={{ width: 'auto' }}
      >
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{ marginRight: 8 }}>
          <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>
        </svg>
        EXPORT EXCEL
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" style={{ marginLeft: 8, transition: 'transform 0.3s', transform: open ? 'rotate(180deg)' : 'none' }}>
          <polyline points="6 9 12 15 18 9"/>
        </svg>
      </button>

      <AnimatePresence>
        {open && (
          <>
            <div className="portal-dropdown-overlay" onClick={() => setOpen(false)} />
            <motion.div 
              initial={{ opacity: 0, y: 10, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 10, scale: 0.95 }}
              className="portal-dropdown-menu"
            >
              <div className="portal-dropdown-header">SELECT RANGE</div>
              {ranges.map(r => (
                <button 
                  key={r.key} 
                  className="portal-dropdown-item" 
                  onClick={() => handleExport(r.key, r.label)}
                >
                  {r.label}
                </button>
              ))}
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
};

const statusColors: Record<string, string> = {
  submitted: 'rgba(255,153,51,0.2)',
  approved: 'rgba(34,197,94,0.2)',
  rejected: 'rgba(239,68,68,0.2)'
};

const statusText: Record<string, string> = {
  submitted: '#ff9933',
  approved: '#22c55e',
  rejected: '#ef4444'
};


/* ——— OVERVIEW ——— */
/* ——— OVERVIEW ——— */
const Overview = () => {
  const [stats, setStats] = useState({ records: 0, hours: 0, disbursements: 0 });
  const [activities, setActivities] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadOverviewTelemetery = async () => {
      try {
        const [recs, tlogs, elogs, alogs] = await Promise.all([
          mockApi.getRecords(),
          mockApi.getTimesheets(),
          mockApi.getExpenses(),
          mockApi.getAuditLogs()
        ]);
        
        const activeRecords = recs.filter((r: any) => r.status !== 'completed').length;
        const totalHours = tlogs.reduce((sum: number, log: any) => sum + (Number(log.hours) || 0), 0);
        const totalDisbursements = elogs.length;

        setStats({
          records: activeRecords,
          hours: totalHours,
          disbursements: totalDisbursements
        });
        
        setActivities(alogs.slice(0, 5));
      } catch (err) {
        console.error("Telemetry failure:", err);
      } finally {
        setLoading(false);
      }
    };
    loadOverviewTelemetery();
  }, []);

  const statCards = [
    { label: 'Active Mandates', value: stats.records.toString().padStart(2, '0'), accent: 'saffron', icon: <><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></> },
    { label: 'Billable Hours (MTD)', value: stats.hours.toFixed(1), accent: 'gold', icon: <><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></> },
    { label: 'Pending Disbursements', value: stats.disbursements.toString().padStart(2, '0'), accent: 'dim', icon: <><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/></> },
  ];

  if (loading) return (
    <div className="portal-content" style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '60vh' }}>
      <div className="intelligence-pulse">SYNCING FIRM TELEMETRY...</div>
    </div>
  );

  return (
    <div className="portal-content">
      {/* Page Header */}
      <div className="portal-page-header-row">
        <div className="portal-page-header" style={{ border: 'none', padding: 0 }}>
          <div className="firm-intel-tag">
            <span className="tag-line" />
            ADVERIS ADVISORS LLP
          </div>
          <h1 className="serif-title" style={{ fontSize: '4.2rem' }}>Intelligence <em>Hub</em></h1>
          <p className="subtitle">Your firm-wide operational command centre for mandates, time tracking, and strategic intelligence.</p>
        </div>
      </div>

      {/* Stats */}
      <div className="portal-stats-grid">
        {statCards.map(c => (
          <div key={c.label} className={`portal-stat-card portal-stat-card--${c.accent}`}>
            <div className="portal-stat-label">
              <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" style={{ opacity: 0.6 }}>
                {c.icon}
              </svg>
              {c.label}
            </div>
            <div className="portal-stat-value" style={{ fontFamily: "'Cormorant Garamond', serif", fontSize: '4.8rem', fontWeight: 500 }}>
              {c.value}
            </div>
          </div>
        ))}
      </div>

      {/* Two-column layout */}
      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) 350px', gap: 32 }}>
        {/* Recent Activity */}
        <div className="portal-panel" style={{ borderTop: '2px solid rgba(0, 153, 255, 0.3)' }}>
          <div className="portal-panel-header">
            <h2>Recent Activity</h2>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.3)" strokeWidth="2">
              <rect x="2" y="3" width="20" height="14" rx="2" ry="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>
            </svg>
          </div>
          <div className="portal-panel-body">
            <div className="portal-activity-list" style={{ marginTop: 0 }}>
              {activities.map(log => (
                <div key={log.id} className="portal-activity-item" style={{ padding: '16px 8px', borderBottom: '1px solid rgba(255,255,255,0.03)' }}>
                  <div className="activity-dot" style={{ background: log.action === 'LOG_TIME' ? 'var(--gold)' : 'var(--saffron)' }} />
                  <div className="activity-main">
                    <div className="activity-title" style={{ fontSize: '0.94rem', color: 'rgba(255,255,255,0.9)' }}>
                      <strong>{log.user_name}</strong> {log.action.replace(/_/g, ' ').toLowerCase()}
                    </div>
                    <div className="activity-meta" style={{ fontSize: '0.78rem', opacity: 0.4 }}>{log.details}</div>
                  </div>
                  <div className="activity-time" style={{ fontSize: '0.7rem', opacity: 0.3 }}>
                    {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                </div>
              ))}
              {activities.length === 0 && (
                <div style={{ padding: '60px 20px', textAlign: 'center', opacity: 0.2 }}>
                  <p className="serif-title" style={{ fontSize: '1.2rem', fontStyle: 'italic' }}>System awaiting activity...</p>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Local Environment */}
        <div className="portal-panel" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '60px 32px', textAlign: 'center' }}>
          <div style={{ color: 'var(--gold)', marginBottom: 20, opacity: 0.8 }}>
            <svg width="42" height="42" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2">
              <ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/>
              <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/>
            </svg>
          </div>
          <p style={{ fontSize: '0.62rem', fontWeight: 700, letterSpacing: '0.15em', textTransform: 'uppercase', color: 'var(--gold)', marginBottom: 24 }}>
            Local Environment
          </p>
          <button
            className="btn-portal-outline-v2"
            onClick={async () => { await mockApi.resetDatabase(); window.location.reload(); }}
          >
            <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" style={{ marginRight: 10, opacity: 0.7 }}>
              <path d="M23 12a11 11 0 0 1-22 0 11 11 0 0 1 22 0z"/><path d="M12 7v5l3 3"/>
            </svg>
            CLEAR LOCAL MEMORY
          </button>
        </div>
      </div>
    </div>
  );
};

/* ——— FORM FIELD ——— */
const FF = ({ label, children }: { label: string, children: React.ReactNode }) => (
  <div className="portal-form-group">
    <label className="portal-form-label">{label}</label>
    {children}
  </div>
);

/* ——— TIMESHEETS ——— */
const Timesheets = () => {
  const [profile, setProfile] = useState<any>(null);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [records, setRecords] = useState<any[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Form State
  const [selectedAccountId, setSelectedAccountId] = useState('');
  const [selectedRecordId, setSelectedRecordId] = useState('');
  const [hours, setHours] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [desc, setDesc] = useState('');
  const [currentStatus, setCurrentStatus] = useState('submitted');

  const loadData = async () => {
    const [p, accs, recs, tlogs] = await Promise.all([
      mockApi.getProfile(),
      mockApi.getAccounts(),
      mockApi.getRecords(),
      mockApi.getTimesheets()
    ]);
    setProfile(p);
    setAccounts(accs);
    setRecords(recs);
    setLogs(tlogs);
  };

  useEffect(() => { loadData(); }, []);

  if (!profile) return null;
  if (profile.role === 'client') return <Navigate to="/dashboard/overview" replace />;

  const accountOptions = accounts.map(a => ({
    id: a.id,
    label: a.account_name,
    sublabel: a.cin_number || 'Institutional Account'
  }));

  const filteredMandates = records.filter(r => r.account_id === selectedAccountId);
  
  const mandateOptions = filteredMandates.map(r => ({
    id: r.id,
    label: r.title,
    sublabel: r.request_number
  }));

  const handleEdit = (log: any) => {
    setEditingId(log.id);
    setSelectedAccountId(log.account_id || '');
    setSelectedRecordId(log.record_id || '');
    setHours(log.hours.toString());
    setDate(log.date);
    setDesc(log.description);
    setCurrentStatus(log.status || 'submitted');
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBulkStatus = async (status: string) => {
    setLoading(true);
    try {
      await mockApi.bulkUpdateTimesheetsStatus(selectedIds, status);
      setSelectedIds([]);
      await loadData();
    } finally { setLoading(false); }
  };

  const handleSelectOne = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      setSelectedIds(logs.map(l => l.id));
    } else {
      setSelectedIds([]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedRecordId) return;
    setLoading(true);
    try {
      const account = accounts.find(a => a.id === selectedAccountId);
      const payload = {
        record_id: selectedRecordId,
        account_id: selectedAccountId,
        account_name: account?.account_name || 'N/A',
        hours: Number(hours),
        date,
        description: desc
      };

      if (editingId) {
        await mockApi.updateTimesheet(editingId, payload);
      } else {
        await mockApi.createTimesheet(payload);
      }

      setShowForm(false);
      setEditingId(null);
      setHours('');
      setDesc('');
      setSelectedRecordId('');
      setSelectedAccountId('');
      await loadData();
    } finally { setLoading(false); }
  };

  const cancelForm = () => {
    setShowForm(false);
    setEditingId(null);
    setHours('');
    setDesc('');
    setSelectedRecordId('');
    setSelectedAccountId('');
  };

  if (showForm) {
    return (
      <div className="portal-content">
        <div className="portal-page-header-row">
          <div>
            <h1 className="serif-title">{editingId ? 'Update' : 'Log'} <em>Time</em></h1>
            <p className="subtitle">Attributing professional hours to institutional mandates.</p>
          </div>
          <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
            {editingId && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: '0.65rem', fontWeight: 700, opacity: 0.4 }}>STATUS</span>
                <span className="portal-badge" style={{ background: statusColors[currentStatus], color: statusText[currentStatus], border: 'none', padding: '6px 16px' }}>
                  {currentStatus.toUpperCase()}
                </span>
              </div>
            )}
            <button onClick={cancelForm} className="btn-portal-outline">BACK TO LIST</button>
          </div>
        </div>
        
        <div className="portal-request-grid-center">
          <div className="portal-auth-card scoping-width">
            <h2 className="card-title">{editingId ? 'Refine' : 'Time'} <em>Entry</em></h2>
            <form onSubmit={handleSubmit}>
              <div style={{ marginBottom: 24 }}>
                <SearchableSelect 
                  label="Client Account"
                  options={accountOptions}
                  value={selectedAccountId}
                  onChange={(id) => { setSelectedAccountId(id); setSelectedRecordId(''); }}
                  placeholder="Search Account Name..."
                />
              </div>
              
              <div style={{ marginBottom: 24, opacity: selectedAccountId ? 1 : 0.4, pointerEvents: selectedAccountId ? 'auto' : 'none', transition: 'all 0.3s' }}>
                <SearchableSelect 
                  label="Associated Mandate"
                  options={mandateOptions}
                  value={selectedRecordId}
                  onChange={setSelectedRecordId}
                  placeholder={selectedAccountId ? "Select Project or ADV Record..." : "Select account first..."}
                />
              </div>

              <div className="portal-form-grid-2">
                <FF label="Hours Quantum">
                  <input required type="number" step="0.5" className="portal-form-control" value={hours} onChange={e => setHours(e.target.value)} placeholder="0.0" />
                </FF>
                <FF label="Activity Date">
                  <input required type="date" className="portal-form-control" value={date} onChange={e => setDate(e.target.value)} />
                </FF>
              </div>
              <FF label="Strategic Work performed">
                <textarea required className="portal-form-control" style={{ minHeight: 140 }} placeholder="Strategic context of the work performed..." value={desc} onChange={e => setDesc(e.target.value)} />
              </FF>
              <button disabled={loading || !selectedRecordId} type="submit" className="btn-portal-primary w-full mt-16">
                {loading ? 'SYNCING...' : editingId ? 'UPDATE LOG' : 'CERTIFY & LOG HOURS'}
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="portal-content" style={{ paddingBottom: selectedIds.length > 0 ? 100 : 0 }}>
      {/* Action Bar */}
      <AnimatePresence>
        {selectedIds.length > 0 && profile?.role === 'admin' && (
          <motion.div 
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            className="portal-batch-bar"
          >
            <div className="batch-content">
              <span className="batch-label">{selectedIds.length} ENTRIES SELECTED</span>
              <div className="batch-actions">
                <button 
                  disabled={loading}
                  onClick={() => handleBulkStatus('approved')} 
                  className="btn-batch btn-batch--approve"
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg>
                  APPROVE
                </button>
                <button 
                  disabled={loading}
                  onClick={() => handleBulkStatus('rejected')} 
                  className="btn-batch btn-batch--reject"
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                  REJECT
                </button>
                <div className="batch-divider" />
                <button onClick={() => setSelectedIds([])} className="btn-batch-text">CANCEL</button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="portal-page-header-row">
        <div className="portal-page-header" style={{ border: 'none', padding: 0 }}>
          <div className="firm-intel-tag"><span className="tag-line" /> PERSONNEL OPERATIONS</div>
          <h1 className="serif-title" style={{ fontSize: '3.5rem' }}>Time <em>Tracking</em></h1>
          <p className="subtitle">Operational audit of professional hours across firm-wide mandates.</p>
        </div>
        <div style={{ display: 'flex', gap: 12 }}>
          {profile?.role === 'admin' && (
            <ExportDropdown data={logs} filename="Adveris_Timesheets" />
          )}
          <button 
            className="btn-portal-primary" 
            style={{ width: 'auto' }}
            onClick={() => setShowForm(true)}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" style={{ marginRight: 10 }}>
              <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
            </svg>
            LOG NEW TIME
          </button>
        </div>
      </div>

      <div className="portal-panel">
        <div className="portal-panel-header">
          <h2>Time Sheet</h2>
          <span className="portal-badge portal-badge--dim">{logs.length} Entries</span>
        </div>
        <div className="portal-table-wrap">
          <table className="portal-table">
            <thead>
              <tr>
                {profile?.role === 'admin' && (
                  <th style={{ width: 40 }}>
                    <input 
                      type="checkbox" 
                      className="portal-checkbox" 
                      checked={selectedIds.length === logs.length && logs.length > 0}
                      onChange={handleSelectAll}
                    />
                  </th>
                )}
                <th>Date</th>
                <th>Professional</th>
                <th>Account</th>
                <th>Mandate</th>
                <th>Status</th>
                <th>Hours</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {logs.map(log => (
                <tr key={log.id} className={selectedIds.includes(log.id) ? 'row-selected' : ''}>
                  {profile?.role === 'admin' && (
                    <td>
                      <input 
                        type="checkbox" 
                        className="portal-checkbox"
                        checked={selectedIds.includes(log.id)}
                        onChange={() => handleSelectOne(log.id)}
                      />
                    </td>
                  )}
                  <td>{new Date(log.date || Date.now()).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}</td>
                  <td style={{ fontWeight: 600, color: 'white' }}>{log.logged_by || 'Admin'}</td>
                  <td style={{ fontSize: '0.82rem', color: 'rgba(255,255,255,0.6)' }}>{log.account_name || 'Individual'}</td>
                  <td className="portal-record-id" style={{ fontSize: '0.7rem' }}>{(records.find(r => r.id === log.record_id)?.request_number) || 'ADV-000'}</td>
                  <td>
                    <span 
                      className="portal-badge" 
                      style={{ 
                        background: statusColors[log.status || 'submitted'],
                        color: statusText[log.status || 'submitted'],
                        borderColor: 'transparent'
                      }}
                    >
                      {log.status || 'submitted'}
                    </span>
                  </td>
                  <td style={{ fontWeight: 700, color: 'white' }}>{log.hours}h</td>
                  <td style={{ textAlign: 'right' }}>
                    <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
                      <button onClick={() => handleEdit(log)} className="btn-portal-record-dots" title="Edit Log">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

/* ——— EXPENSES ——— */
const Expenses = () => {
  const [profile, setProfile] = useState<any>(null);
  const [accounts, setAccounts] = useState<any[]>([]);
  const [entries, setEntries] = useState<any[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  // Form State
  const [selectedAccountId, setSelectedAccountId] = useState('');
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState('Regulatory Fees');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [desc, setDesc] = useState('');
  const [url, setUrl] = useState('');
  const [currentStatus, setCurrentStatus] = useState('submitted');

  const loadData = async () => {
    const [p, accs, eEntries] = await Promise.all([
      mockApi.getProfile(),
      mockApi.getAccounts(),
      mockApi.getExpenses()
    ]);
    setProfile(p);
    setAccounts(accs);
    setEntries(eEntries);
  };

  useEffect(() => { loadData(); }, []);

  if (!profile) return null;

  const accountOptions = accounts.map(a => ({
    id: a.id,
    label: a.account_name,
    sublabel: a.cin_number || 'Institutional Account'
  }));

  const handleEdit = (entry: any) => {
    setEditingId(entry.id);
    setSelectedAccountId(entry.account_id || '');
    setAmount(entry.amount.toString());
    setCategory(entry.category || 'Regulatory Fees');
    setDate(entry.date);
    setDesc(entry.description);
    setUrl(entry.url || '');
    setCurrentStatus(entry.status || 'submitted');
    setShowForm(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBulkStatus = async (status: string) => {
    setLoading(true);
    try {
      await mockApi.bulkUpdateExpensesStatus(selectedIds, status);
      setSelectedIds([]);
      await loadData();
    } finally { setLoading(false); }
  };

  const handleSelectOne = (id: string) => {
    setSelectedIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const handleSelectAll = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.checked) {
      setSelectedIds(entries.map(ent => ent.id));
    } else {
      setSelectedIds([]);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAccountId) return;
    setLoading(true);
    try {
      const account = accounts.find(a => a.id === selectedAccountId);
      const payload = {
        account_id: selectedAccountId,
        account_name: account?.account_name || 'N/A',
        amount: Number(amount),
        category,
        date,
        description: desc,
        url
      };

      if (editingId) {
        await mockApi.updateExpense(editingId, payload);
      } else {
        await mockApi.createExpense(payload);
      }

      setShowForm(false);
      setEditingId(null);
      setAmount('');
      setDesc('');
      setUrl('');
      setSelectedAccountId('');
      await loadData();
    } finally { setLoading(false); }
  };

  const cancelForm = () => {
    setShowForm(false);
    setEditingId(null);
    setAmount('');
    setDesc('');
    setUrl('');
    setSelectedAccountId('');
  };

  if (showForm) {
    return (
      <div className="portal-content">
        <div className="portal-page-header-row">
          <div>
            <h1 className="serif-title">{editingId ? 'Update' : 'Record'} <em>Expense</em></h1>
            <p className="subtitle">Official disbursement logging for client entity.</p>
          </div>
          <div style={{ display: 'flex', gap: 16, alignItems: 'center' }}>
            {editingId && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <span style={{ fontSize: '0.65rem', fontWeight: 700, opacity: 0.4 }}>STATUS</span>
                <span className="portal-badge" style={{ background: statusColors[currentStatus], color: statusText[currentStatus], border: 'none', padding: '6px 16px' }}>
                  {currentStatus.toUpperCase()}
                </span>
              </div>
            )}
            <button onClick={cancelForm} className="btn-portal-outline">BACK TO LIST</button>
          </div>
        </div>
        
        <div className="portal-request-grid-center">
          <div className="portal-auth-card scoping-width">
            <h2 className="card-title">{editingId ? 'Refine' : 'Expense'} <em>Log</em></h2>
            <form onSubmit={handleSubmit}>
              <div style={{ marginBottom: 24 }}>
                <SearchableSelect 
                  label="Client Account"
                  options={accountOptions}
                  value={selectedAccountId}
                  onChange={setSelectedAccountId}
                  placeholder="Search Account Name..."
                />
              </div>

              <div className="portal-form-grid-2">
                <FF label="Amount (INR)">
                  <input required type="number" className="portal-form-control" value={amount} onChange={e => setAmount(e.target.value)} placeholder="0.00" />
                </FF>
                <FF label="Category">
                  <select className="portal-form-control" value={category} onChange={e => setCategory(e.target.value)}>
                    <option>Regulatory Fees</option>
                    <option>Traveling & Lodging</option>
                    <option>Printing & Stationery</option>
                    <option>Professional Charges</option>
                  </select>
                </FF>
              </div>
              <div className="portal-form-grid-2">
                <FF label="Incurred Date">
                  <input required type="date" className="portal-form-control" value={date} onChange={e => setDate(e.target.value)} />
                </FF>
                <FF label="Receipt URL (Optional)">
                  <input type="url" className="portal-form-control" value={url} onChange={e => setUrl(e.target.value)} placeholder="https://..." />
                </FF>
              </div>
              <FF label="Rationale & Justification">
                <textarea required className="portal-form-control" style={{ minHeight: 120 }} placeholder="Detailed reason for this disbursement..." value={desc} onChange={e => setDesc(e.target.value)} />
              </FF>
              <button disabled={loading || !selectedAccountId} type="submit" className="btn-portal-primary w-full mt-16">
                {loading ? 'POSTING...' : editingId ? 'UPDATE DISBURSEMENT' : 'CERTIFY DISBURSEMENT'}
              </button>
            </form>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="portal-content" style={{ paddingBottom: selectedIds.length > 0 ? 100 : 0 }}>
      {/* Action Bar */}
      <AnimatePresence>
        {selectedIds.length > 0 && profile?.role === 'admin' && (
          <motion.div 
            initial={{ y: 100, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 100, opacity: 0 }}
            className="portal-batch-bar"
          >
            <div className="batch-content">
              <span className="batch-label">{selectedIds.length} DISBURSEMENTS SELECTED</span>
              <div className="batch-actions">
                <button 
                  disabled={loading}
                  onClick={() => handleBulkStatus('approved')} 
                  className="btn-batch btn-batch--approve"
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><polyline points="20 6 9 17 4 12"/></svg>
                  APPROVE
                </button>
                <button 
                  disabled={loading}
                  onClick={() => handleBulkStatus('rejected')} 
                  className="btn-batch btn-batch--reject"
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
                  REJECT
                </button>
                <div className="batch-divider" />
                <button onClick={() => setSelectedIds([])} className="btn-batch-text">CANCEL</button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="portal-page-header-row">
        <div className="portal-page-header" style={{ border: 'none', padding: 0 }}>
          <div className="firm-intel-tag"><span className="tag-line" /> FINANCIAL AUDIT</div>
          <h1 className="serif-title" style={{ fontSize: '3.5rem' }}>Expense <em>List</em></h1>
          <p className="subtitle">Tracking out-of-pocket expenses and professional disbursements.</p>
        </div>
        <div style={{ display: 'flex', gap: 12 }}>
          {profile?.role === 'admin' && (
            <ExportDropdown data={entries} filename="Adveris_Expenses" />
          )}
          <button 
            className="btn-portal-primary" 
            style={{ width: 'auto' }}
            onClick={() => setShowForm(true)}
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" style={{ marginRight: 10 }}>
              <line x1="12" y1="5" x2="12" y2="19" /><line x1="5" y1="12" x2="19" y2="12" />
            </svg>
            RECORD EXPENSE
          </button>
        </div>
      </div>

      <div className="portal-panel">
        <div className="portal-panel-header">
          <h2>Expense List</h2>
          <span className="portal-badge portal-badge--dim">{entries.length} Records</span>
        </div>
        <div className="portal-table-wrap">
          <table className="portal-table">
            <thead>
              <tr>
                {profile?.role === 'admin' && (
                  <th style={{ width: 40 }}>
                    <input 
                      type="checkbox" 
                      className="portal-checkbox" 
                      checked={selectedIds.length === entries.length && entries.length > 0}
                      onChange={handleSelectAll}
                    />
                  </th>
                )}
                <th>Date</th>
                <th>Category</th>
                <th>Account</th>
                <th>URL</th>
                <th>Status</th>
                <th style={{ textAlign: 'right' }}>Amount (INR)</th>
                <th style={{ textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {entries.map(e => (
                <tr key={e.id} className={selectedIds.includes(e.id) ? 'row-selected' : ''}>
                  {profile?.role === 'admin' && (
                    <td>
                      <input 
                        type="checkbox" 
                        className="portal-checkbox"
                        checked={selectedIds.includes(e.id)}
                        onChange={() => handleSelectOne(e.id)}
                      />
                    </td>
                  )}
                  <td>{new Date(e.date || Date.now()).toLocaleDateString('en-IN', { day: '2-digit', month: 'short' })}</td>
                  <td>
                    <span className="portal-badge" style={{ background: 'rgba(255,255,255,0.05)', color: 'rgba(255,153,51,0.6)', border: '1px solid rgba(255,153,51,0.15)' }}>
                      {e.category || 'Disbursement'}
                    </span>
                  </td>
                  <td style={{ fontSize: '0.85rem', color: 'rgba(255,255,255,0.6)' }}>{e.account_name || 'Individual'}</td>
                  <td>
                    {e.url ? (
                      <a href={e.url} target="_blank" rel="noopener noreferrer" style={{ color: 'var(--gold)', fontSize: '0.7rem', textDecoration: 'underline' }}>View Receipt</a>
                    ) : (
                      <span style={{ fontSize: '0.7rem', opacity: 0.2 }}>N/A</span>
                    )}
                  </td>
                  <td>
                    <span 
                      className="portal-badge" 
                      style={{ 
                        background: statusColors[e.status || 'submitted'],
                        color: statusText[e.status || 'submitted'],
                        borderColor: 'transparent'
                      }}
                    >
                      {e.status || 'submitted'}
                    </span>
                  </td>
                  <td style={{ textAlign: 'right', fontWeight: 700, color: 'var(--gold)' }}>₹{Number(e.amount).toLocaleString('en-IN')}</td>
                  <td style={{ textAlign: 'right' }}>
                    <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8 }}>
                      <button onClick={() => handleEdit(e)} className="btn-portal-record-dots" title="Edit Expense">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {entries.length === 0 && (
                <tr>
                  <td colSpan={8} style={{ textAlign: 'center', padding: '60px', color: 'rgba(255,255,255,0.2)' }}>
                    No disbursement records found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

/* ——— CLIENT OVERVIEW (for client role) ——— */
const ClientOverview = () => {
  const [profile, setProfile] = useState<any>(null);
  const [records, setRecords] = useState<any[]>([]);

  useEffect(() => {
    mockApi.getProfile().then(async p => {
      setProfile(p);
      const recs = await mockApi.getRecords();
      // Filter to only the client's own mandates
      setRecords(recs.filter((r: any) => r.account_id === p.account_id || r.submitted_by === p.id));
    });
  }, []);

  if (!profile) return null;

  return (
    <div className="portal-content">
      <div className="portal-page-header">
        <div style={{ fontSize: '0.65rem', fontWeight: 700, letterSpacing: '0.25em', textTransform: 'uppercase', color: 'var(--saffron)', marginBottom: 14, display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ width: 20, height: 1.5, background: 'var(--saffron)', display: 'inline-block' }} />
          Client Portal
        </div>
        <h1>Welcome, <em>{profile.full_name}</em></h1>
        <p style={{ marginTop: 12, fontSize: '1rem', color: 'rgba(255,255,255,0.5)', fontWeight: 300 }}>
          Track your active mandates and submit new service requests below.
        </p>
      </div>

      <div className="portal-panel">
        <div className="portal-panel-header">
          <h2>Your Mandates</h2>
        </div>
        <div className="portal-panel-body">
          {records.length === 0 ? (
            <p style={{ color: 'rgba(255,255,255,0.3)', fontStyle: 'italic', textAlign: 'center', padding: '40px 0' }}>No mandates submitted yet.</p>
          ) : (
            records.map((r: any) => (
              <div key={r.id} style={{ padding: '16px 0', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                  <span style={{ fontSize: '0.85rem', color: 'white', fontWeight: 600 }}>{r.request_number} — {r.primary_service}</span>
                  <span style={{ fontSize: '0.7rem', padding: '3px 10px', borderRadius: 'var(--radius-pill)', background: 'rgba(255,153,51,0.15)', color: 'var(--saffron)', fontWeight: 700, textTransform: 'uppercase' }}>{r.status}</span>
                </div>
                <p style={{ fontSize: '0.78rem', color: 'rgba(255,255,255,0.4)', marginTop: 4 }}>{r.description}</p>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};

/* ——— DASHBOARD ROOT ——— */
const Dashboard = () => {
  const [profile, setProfile] = useState<any>(null);

  useEffect(() => {
    mockApi.getProfile().then(setProfile);
  }, []);

  if (!profile) return null;

  const isClient = profile.role === 'client';

  return (
    <PortalLayout profile={profile}>
      <Routes>
        <Route path="/" element={<Navigate to={isClient ? "/dashboard/overview" : "/dashboard/overview"} replace />} />
        <Route path="overview" element={isClient ? <ClientOverview /> : <Overview />} />
        <Route path="new-request" element={<NewRequest />} />
        <Route path="records" element={<RecordsList />} />
        <Route path="records/:id" element={<MandateDetail />} />
        <Route path="timesheets" element={<Timesheets />} />
        <Route path="expenses" element={<Expenses />} />
        <Route path="service-hub" element={<AuditLogs />} />
        <Route path="crm" element={<CRMHub />} />
        <Route path="crm/accounts/:id" element={<AccountDetail />} />
        <Route path="crm/clients/:id" element={<ClientDetail />} />
        <Route path="*" element={
          <div className="portal-content" style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', minHeight: '60vh', textAlign: 'center' }}>
            <p style={{ fontFamily: 'var(--font-serif)', fontSize: '1.8rem', fontStyle: 'italic', color: 'rgba(255,255,255,0.2)' }}>
              Module under development...
            </p>
          </div>
        } />
      </Routes>
    </PortalLayout>
  );
};

export default Dashboard;
