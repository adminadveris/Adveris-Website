import React, { useState, useEffect } from 'react';
import { mockApi } from '../lib/mockApi';
import SearchableSelect from './SearchableSelect';

/* ─── Shared UI Components ─── */
const ModalShell = ({ title, sub, onClose, children }: { title: React.ReactNode; sub?: string; onClose: () => void; children: React.ReactNode }) => (
  <div style={{
    position: 'fixed', inset: 0, zIndex: 3000,
    background: 'rgba(5, 10, 25, 0.88)', backdropFilter: 'blur(14px)',
    display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 24
  }} onClick={e => { if (e.target === e.currentTarget) onClose(); }}>
    <div style={{
      background: 'rgba(13,27,62,0.85)', border: '1px solid rgba(255,255,255,0.1)',
      borderRadius: 'var(--radius)', padding: 40, width: '100%', maxWidth: 540,
      backdropFilter: 'blur(20px)', boxShadow: '0 40px 80px rgba(0,0,0,0.5)'
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 32 }}>
        <div>
          {sub && <p style={{ fontSize: '0.6rem', fontWeight: 700, letterSpacing: '0.22em', textTransform: 'uppercase', color: 'var(--saffron)', marginBottom: 6 }}>{sub}</p>}
          <h2 style={{ fontFamily: 'var(--font-serif)', fontSize: '1.8rem', color: 'white', fontWeight: 400, lineHeight: 1.2 }}>{title}</h2>
        </div>
        <button onClick={onClose} style={{ background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)', borderRadius: '50%', width: 36, height: 36, color: 'rgba(255,255,255,0.6)', cursor: 'pointer', fontSize: '1rem', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 2 }}>×</button>
      </div>
      {children}
    </div>
  </div>
);

const FormField = ({ label, children }: { label: string; children: React.ReactNode }) => (
  <div>
    <label style={{ display: 'block', fontSize: '0.6rem', fontWeight: 700, letterSpacing: '0.2em', textTransform: 'uppercase', color: 'rgba(255,255,255,0.4)', marginBottom: 8 }}>{label}</label>
    {children}
  </div>
);

const inputStyle: React.CSSProperties = {
  width: '100%', padding: '12px 16px',
  background: 'rgba(255,255,255,0.05)', border: '1.5px solid rgba(255,255,255,0.1)',
  borderRadius: 'var(--radius-sm)', color: 'white', fontSize: '0.9rem',
  fontFamily: 'var(--font-sans)', outline: 'none', transition: 'border-color 0.2s ease'
};

/* ─── ACCOUNT MODAL ─── */
export const AccountModal = ({ account, onClose, onSaved }: { account?: any; onClose: () => void; onSaved: () => void }) => {
  const [data, setData] = useState({
    account_name: account?.account_name || '',
    cin_number: account?.cin_number || '',
    pan_number: account?.pan_number || '',
    gstin_number: account?.gstin_number || '',
    industry: account?.industry || ''
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSave = async () => {
    setError(null);
    setSaving(true);
    try {
      if (account?.id) await mockApi.updateAccount(account.id, data);
      else await mockApi.createAccount(data);
      onSaved();
      onClose();
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred.");
    } finally { setSaving(false); }
  };

  return (
    <ModalShell title={account ? <>Edit <em>Account</em></> : <>New <em>Account</em></>} sub="Legal Entity" onClose={onClose}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        {error && (
          <div style={{ padding: '12px 16px', background: 'rgba(255, 71, 87, 0.1)', border: '1px solid rgba(255, 71, 87, 0.3)', borderRadius: 8, color: '#ff4757', fontSize: '0.8rem', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 10, animation: 'shake 0.4s ease' }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
            {error}
          </div>
        )}
        <FormField label="Full Legal Name">
          <input style={inputStyle} value={data.account_name} onChange={e => setData({...data, account_name: e.target.value})} placeholder="e.g. Adveris Advisors LLP" required />
        </FormField>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <FormField label="Registration (CIN/LLPIN)">
            <input style={inputStyle} value={data.cin_number} onChange={e => setData({...data, cin_number: e.target.value})} placeholder="U1234..." />
          </FormField>
          <FormField label="Industry / Sector">
            <input style={inputStyle} value={data.industry} onChange={e => setData({...data, industry: e.target.value})} placeholder="e.g. Finance" />
          </FormField>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <FormField label="PAN Number">
            <input style={inputStyle} value={data.pan_number} onChange={e => setData({...data, pan_number: e.target.value})} placeholder="ABCDE1234F" />
          </FormField>
          <FormField label="GST Number">
            <input style={inputStyle} value={data.gstin_number} onChange={e => setData({...data, gstin_number: e.target.value})} placeholder="29XXXXX..." />
          </FormField>
        </div>
        <div style={{ display: 'flex', gap: 12, marginTop: 12 }}>
          <button onClick={onClose} style={{ flex: 1, padding: '12px', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 'var(--radius-pill)', color: 'rgba(255,255,255,0.5)', cursor: 'pointer', fontSize: '0.75rem', fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase' }}>Cancel</button>
          <button onClick={handleSave} disabled={saving || !data.account_name} style={{ flex: 2, padding: '12px 24px', background: saving ? 'rgba(255,153,51,0.5)' : 'var(--saffron)', color: 'var(--navy)', border: 'none', borderRadius: 'var(--radius-pill)', fontSize: '0.75rem', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', cursor: saving ? 'not-allowed' : 'pointer', transition: 'all 0.2s ease' }}>
            {saving ? 'Saving...' : 'Save Account'}
          </button>
        </div>
      </div>
    </ModalShell>
  );
};

/* ─── CLIENT MODAL ─── */
export const ClientModal = ({ client, fixedAccountId, onClose, onSaved }: { client?: any; fixedAccountId?: string; onClose: () => void; onSaved: () => void }) => {
  const [accounts, setAccounts] = useState<any[]>([]);
  const [data, setData] = useState({
    account_id: fixedAccountId || client?.account_id || '',
    client_name: client?.client_name || '',
    designation: client?.designation || '',
    address: client?.address || '',
    phone_1: client?.phone_1 || '',
    phone_2: client?.phone_2 || '',
    phone_3: client?.phone_3 || '',
    email_1: client?.email_1 || '',
    email_2: client?.email_2 || '',
    email_3: client?.email_3 || '',
  });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!fixedAccountId) {
      mockApi.getAccounts().then(setAccounts);
    }
  }, [fixedAccountId]);

  const handleSave = async () => {
    setError(null);
    setSaving(true);
    try {
      if (client?.id) await mockApi.updateClient(client.id, data);
      else await mockApi.createClient(data);
      onSaved();
      onClose();
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred.");
    } finally { setSaving(false); }
  };

  return (
    <ModalShell title={client ? <>Edit <em>Client</em></> : <>New <em>Client</em></>} sub="Contact Individual" onClose={onClose}>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
        {error && (
          <div style={{ padding: '12px 16px', background: 'rgba(255, 71, 87, 0.1)', border: '1px solid rgba(255, 71, 87, 0.3)', borderRadius: 8, color: '#ff4757', fontSize: '0.8rem', fontWeight: 600, display: 'flex', alignItems: 'center', gap: 10, animation: 'shake 0.4s ease' }}>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>
            {error}
          </div>
        )}
        <FormField label="Full Name">
          <input style={inputStyle} value={data.client_name} onChange={e => setData({...data, client_name: e.target.value})} placeholder="e.g. John Doe" required />
        </FormField>
        
        {!fixedAccountId ? (
          <div className="portal-form-group">
          <label className="portal-form-label">Associated Account</label>
          <SearchableSelect
            options={accounts.map(acc => ({ id: acc.id, label: acc.account_name, sublabel: acc.industry }))}
            value={data.account_id}
            onChange={val => setData({ ...data, account_id: val })}
            placeholder="Search Account..."
          />
        </div>
        ) : (
          <FormField label="Associated Account">
            <input style={{ ...inputStyle, opacity: 0.5, cursor: 'not-allowed' }} value={accounts.find(a => a.id === fixedAccountId)?.account_name || 'Current Account'} disabled />
          </FormField>
        )}

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <FormField label="Designation">
            <input style={inputStyle} value={data.designation} onChange={e => setData({...data, designation: e.target.value})} placeholder="e.g. Director" />
          </FormField>
          <FormField label="Primary Mobile">
            <input style={inputStyle} value={data.phone_1} onChange={e => setData({...data, phone_1: e.target.value})} placeholder="+91 ..." />
          </FormField>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <FormField label="Secondary Mobile">
            <input style={inputStyle} value={data.phone_2} onChange={e => setData({...data, phone_2: e.target.value})} placeholder="+91 ..." />
          </FormField>
          <FormField label="Alternate Phone">
            <input style={inputStyle} value={data.phone_3} onChange={e => setData({...data, phone_3: e.target.value})} placeholder="+91 ..." />
          </FormField>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          <FormField label="Primary Email">
            <input style={inputStyle} value={data.email_1} onChange={e => setData({...data, email_1: e.target.value})} placeholder="john@example.com" />
          </FormField>
          <FormField label="Secondary Email">
            <input style={inputStyle} value={data.email_2} onChange={e => setData({...data, email_2: e.target.value})} placeholder="personal@email.com" />
          </FormField>
          <FormField label="Alternate Email">
            <input style={inputStyle} value={data.email_3} onChange={e => setData({...data, email_3: e.target.value})} placeholder="other@email.com" />
          </FormField>
        </div>

        <FormField label="Physical Address">
          <textarea style={{ ...inputStyle, resize: 'vertical' }} rows={2} value={data.address} onChange={e => setData({...data, address: e.target.value})} placeholder="Office or Residential address..." />
        </FormField>

        <div style={{ display: 'flex', gap: 12, marginTop: 12 }}>
          <button onClick={onClose} style={{ flex: 1, padding: '12px', background: 'rgba(255,255,255,0.04)', border: '1px solid rgba(255,255,255,0.08)', borderRadius: 'var(--radius-pill)', color: 'rgba(255,255,255,0.5)', cursor: 'pointer', fontSize: '0.75rem', fontWeight: 700, letterSpacing: '0.1em', textTransform: 'uppercase' }}>Cancel</button>
          <button onClick={handleSave} disabled={saving || !data.client_name || (!fixedAccountId && !data.account_id)} style={{ flex: 2, padding: '12px 24px', background: saving ? 'rgba(255,153,51,0.5)' : 'var(--saffron)', color: 'var(--navy)', border: 'none', borderRadius: 'var(--radius-pill)', fontSize: '0.75rem', fontWeight: 700, letterSpacing: '0.12em', textTransform: 'uppercase', cursor: saving ? 'not-allowed' : 'pointer', transition: 'all 0.2s ease' }}>
            {saving ? 'Saving...' : 'Save Client'}
          </button>
        </div>
      </div>
      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          25% { transform: translateX(-4px); }
          75% { transform: translateX(4px); }
        }
      `}</style>
    </ModalShell>
  );
};
